import re


def validare_optiune(optiune):
    if optiune in ["1", "2", "3"]:
        return True
    else:
        print("Optiune invalida. Alegeti 1, 2 sau  3.")
        return False

def validare_ingredient(ingredient):
    #conține doar litere si are  1-15 caractere.
    return re.match(r'^[a-zA-Z]{1,15}$', ingredient)

def validare_numar_ingrediente(numar):
    #nr de ingrediente este format din 1 sau 2 cifre.
    return re.match(r'^\d{1,2}$', numar)
