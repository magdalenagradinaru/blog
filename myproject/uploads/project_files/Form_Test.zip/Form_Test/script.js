document.querySelector(".black").addEventListener("click", function() {
    document.body.style.backgroundColor = "black";

    const container = document.querySelector(".container");
    container.style.backgroundColor = "white";

    const boxes = document.querySelectorAll(".quiz-box");
    boxes.forEach(box => {
        box.style.backgroundColor = "rgb(201, 191, 191)";
    });
});

document.querySelector(".pink").addEventListener("click", function() {
    document.body.style.backgroundColor = "pink";

    const container = document.querySelector(".container");
    container.style.backgroundColor = "palevioletred";

    const boxes = document.querySelectorAll(".quiz-box");
    boxes.forEach(box => {
        box.style.backgroundColor = "rgb(239, 188, 197)";
    });
});

document.querySelector(".blue").addEventListener("click", function() {
    document.body.style.backgroundColor = "rgb(110, 110, 168)";

    const container = document.querySelector(".container");
    container.style.backgroundColor = "rgb(25, 25, 61)";

    const boxes = document.querySelectorAll(".quiz-box");
    boxes.forEach(box => {
        box.style.backgroundColor = "rgb(157, 176, 215)";
    });
});



  