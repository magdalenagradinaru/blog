from django.shortcuts import render, get_object_or_404
from .models import Post, Comment
from .forms import CommentForm
from django.views.generic import ListView
from django.core.paginator import Paginator,EmptyPage, PageNotAnInteger


# Funcția pentru afișarea listei de postări
class PostListView(ListView):
    queryset = Post.objects.all()
    context_object_name = 'posts'
    paginate_by = 3
    template_name = 'blog/post/list.html'


# Funcția pentru afișarea detaliilor unei postări
def post_detail(request, year, month, day, post):
    post = get_object_or_404(
        Post,
        slug=post,
        publish__year=year,
        publish__month=month,
        publish__day=day
    )

    # Lista comentariilor active pentru postarea curentă
    comments = post.comments.filter(active=True)
    new_comment = None
    comment_form = None

    if request.method == 'POST':
        # Utilizatorul a trimis comentariul
        comment_form = CommentForm(data=request.POST)

        if comment_form.is_valid():
            # Creem comentariul, dar încă nu-l salvăm în baza de date
            new_comment = comment_form.save(commit=False)

            # Legăm comentariul de postarea curentă
            new_comment.post = post

            # Salvăm comentariul în baza de date
            new_comment.save()
        else:
            # Dacă formularul nu este valid, refacem formularul
            comment_form = CommentForm()



    return render(request, 'blog/post/detail.html', {
        'post': post,
        'comments': comments,
        'new_comment': new_comment,
        'comment_form': comment_form
    })
