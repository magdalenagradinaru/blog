<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aplication</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <button class="top-button black">Black</button>
  <button class="top-button pink">Pink</button>
  <button class="top-button blue">Blue</button>
  
  <div class="container">
    <div class="quiz-wrapper" id="question1">
      <div class="quiz-box" id="quiz">
            
        <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Verifica daca numele a fost introdus
if(isset($_POST['numele']) && !empty($_POST['numele'])) {

    $fisier = fopen("punctaj.txt", "a"); 

    if($fisier === false) {
        // Afisati un mesaj de eroare
        echo "Eroare: Fișierul nu a putut fi deschis pentru scriere.";
    }

    $punctaj = 0; 


    // Intrebari de tip radio
    // Prima intrebare
    if (isset($_POST['option1']) && $_POST['option1'] === 'd') {
        $punctaj += 10;
    } elseif ($_POST['option1'] === 'b' || $_POST['option1'] === 'c' || $_POST['option1'] === 'a') {
        $punctaj += 0;
    }
    

    // A doua intrebare
    if(isset($_POST['option2']) && $_POST['option2']==='a') {
        $punctaj += 10;
    } elseif($_POST['option2']==='b' || $_POST['option2'] ==='c' || $_POST['option2']==='d') {
        $punctaj += 0;
    }

    // A treia intrebare
    if(isset($_POST['option3']) && $_POST['option3']==='a') {
        $punctaj += 10;
    } elseif($_POST['option3']==='b' || $_POST['option3']==='c' || $_POST['option3']==='d') {
        $punctaj += 0;
    }

    // Intrebari de tip checkbox
    // A patra intrebare
    if((isset($_POST['option4_a']) && isset($_POST['option4_c'])) && (!empty($_POST['option4_a']) && !empty($_POST['option4_c']))) {
        $punctaj += 10;
    } elseif((isset($_POST['option4_b']) || isset($_POST['option4_d'])) && (!empty($_POST['option4_b']) || !empty($_POST['option4_d']))) {
        $punctaj += 0;
    } elseif((isset($_POST['option4_a']) && isset($_POST['option4_b'])) || (isset($_POST['option4_a']) && isset($_POST['option4_d'])) || (isset($_POST['option4_c']) && isset($_POST['option4_b'])) || (isset($_POST['option4_c']) && isset($_POST['option4_d']))) {
        $punctaj += 5;
    } elseif (((isset($_POST['option4_a']) && isset($_POST['option4_b']) && isset($_POST['option4_c']) && isset($_POST['option4_d'])))){
        $punctaj +=0;
    }

    // A cincea intrebare
    if((isset($_POST['option5_b']) && isset($_POST['option5_c'])) && (!empty($_POST['option5_b']) && !empty($_POST['option5_c']))) {
        $punctaj += 10;
    } elseif((isset($_POST['option5_a']) || isset($_POST['option5_d'])) && (!empty($_POST['option5_a']) || !empty($_POST['option5_d']))) {
        $punctaj += 0;
    } elseif((isset($_POST['option5_a']) && isset($_POST['option5_b'])) || (isset($_POST['option5_a']) && isset($_POST['option5_c'])) || (isset($_POST['option5_b']) && isset($_POST['option5_b'])) || (isset($_POST['option5_c']) && isset($_POST['option5_d']))) {
        $punctaj += 5;
    }  elseif (((isset($_POST['option5_a']) && isset($_POST['option5_b']) && isset($_POST['option5_c']) && isset($_POST['option5_d'])))){
        $punctaj +=0;
    }

    // A sasea intrebare
    if((isset($_POST['option6_a']) && isset($_POST['option6_d'])) && (!empty($_POST['option6_a']) && !empty($_POST['option6_d']))) {
        $punctaj += 10;
    } elseif((isset($_POST['option6_b']) || isset($_POST['option6_c'])) && (!empty($_POST['option6_b']) || !empty($_POST['option6_c']))) {
        $punctaj += 0;
    } elseif((isset($_POST['option6_a']) && isset($_POST['option6_b'])) || (isset($_POST['option6_a']) && isset($_POST['option6_c'])) || (isset($_POST['option6_c']) && isset($_POST['option6_d'])) || (isset($_POST['option6_b']) && isset($_POST['option6_d']))) {
        $punctaj += 5;
    }  elseif (((isset($_POST['option6_a']) && isset($_POST['option6_b']) && isset($_POST['option6_c']) && isset($_POST['option6_d'])))){
        $punctaj +=0;
    }


            // Afiseaza numele, punctajul total și mesajul
            echo "<p>Numele: {$_POST['numele']}</p>";
            echo "<p>Punctaj total: $punctaj</p>";
            echo "<p>$rezultat_mesaj</p>";

            // Scrierea rezultatelor în fișier
            fwrite($fisier, $_POST['numele']."\t". "Punctaj total: " . $punctaj . "\n");
            fclose($fisier);
        }


$punctaje = [];
$medie = 0;

$fisier_punctaje = fopen("punctaj.txt", "r");
if ($fisier_punctaje) {
    while (($linie = fgets($fisier_punctaje)) !== false) {
        // Extragem punctajul din linie și îl adăugăm în vector
        $punctaj = explode(" ", $linie)[2]; // Extragem al treilea element din linie, care conține punctajul
        $punctaje[] = (int)$punctaj; // Convertim punctajul într-un număr întreg și îl adăugăm în vector
    }

    // Calculăm media aritmetică a punctajelor
    $numar_punctaje = count($punctaje);
    $suma_punctaje = array_sum($punctaje);
    if ($numar_punctaje > 0) {
        $medie = $suma_punctaje / $numar_punctaje;
    }

    fclose($fisier_punctaje);
}

// Verificăm dacă utilizatorul a trimis un nume și dacă există punctaje în fișier
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['numele']) && !empty($_POST['numele']) && $medie > 0) {
    $nume_utilizator = $_POST['numele'];
    $punctaj_utilizator = $_POST['punctaj'];

    // Afisăm mesajul corespunzător în funcție de punctajul utilizatorului
    if ($punctaj_utilizator > $medie) {
        echo "<p> Felicitări, $nume_utilizator! Punctajul tău este bun, mai mare decât media punctelor din fișier ($medie).</p>";
    } else {
        echo "<p> Îmi pare rău, $nume_utilizator. Punctajul tău ($punctaj_utilizator) nu este chiar bun, mai mic decât media punctelor din fișier ($medie).</p>";
    }
}

} else {
    // Afiseaza un mesaj de eroare daca numele nu a fost introdus
    echo "Eroare: ceva nu merge."; 
}

 ?>

</div>
    </div>
        </div>

  <script src="script.js"></script>
</body>
</html>
 