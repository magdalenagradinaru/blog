# Importăm funcțiile de validare din modulul validari
import validari
import gest_fisier

# Program principal
def meniu_principal():
    while True:
        print("\nAlege o opțiune: ")
        print("1 - Caută ingredient și afișează rezultat")
        print("2 - Adaugă un fel de mâncare și ingrediente")
        print("3 - Ieșire")

        optiune = input("-> ").strip()

        if validari.validare_optiune(optiune):  # Apelăm funcția de validare
            if optiune == "1":
                ingredient = input("Introdu numele ingredientului -> ").lower()
                if validari.validare_ingredient(ingredient):
                    gest_fisier.cauta_ingredient(ingredient)
                else:
                    print("Nume invalid. Folosiți doar litere (3 - 15 caractere).")

            elif optiune == "2":
                fel = input("Introdu tipul de mâncare -> ").lower()
                nr_ingrediente = input("Introdu numărul de ingrediente -> ")
                if validari.validare_numar_ingrediente(nr_ingrediente):
                    numar_ingrediente = int(nr_ingrediente)
                    ingrediente = []
                    for i in range(numar_ingrediente):
                        ingredient = input(f"Ingredientul {i + 1} -> ").lower()
                        if validari.validare_ingredient(ingredient):
                            ingrediente.append(ingredient)
                        else:
                            print("Nume invalid. Reintrodu ingredientul.")
                            break
                    else:
                        gest_fisier.scriere_in_fisier(fel, ingrediente)
                        print("Felul de mâncare și ingredientele au fost salvate.")
                else:
                    print("Număr invalid. Introduceți un număr de 1-2 cifre.")

            elif optiune == "3":
                break

# Apelarea funcției principale pentru a începe programul
meniu_principal()
