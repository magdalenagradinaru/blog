from django.contrib import admin
from .models import Post,Comment

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'slug', 'author', 'publish', 'status','image') #in lista publicatiilor se vor afisa doar acele campuri pe care le-am specificat aici
    list_filter = ('status', 'created', 'publish', 'author')        #in dreapta paginii va aparea blocul cu filtre pentru publicatii
    search_fields = ('title', 'body')                               #bara de cautare
    prepopulated_fields = {'slug': ('title',)}
    raw_id_fields = ('author',)
    date_hierarchy = 'publish'                                      #link-uri de navigare in baza datei din bara de cautare
    ordering = ('status', 'publish')                                #postarile vor fi ordonate dupa campurile status si publish

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('name','email','post','created','active')
    list_filter = ('active','created','updated')
    search_fields = ('nema','email','body')

