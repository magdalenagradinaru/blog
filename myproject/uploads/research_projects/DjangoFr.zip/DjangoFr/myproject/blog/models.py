from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

class Post(models.Model):
    STATUS_CHOICES = (
        ('draft', 'Draft'),
        ('published', 'Published'),
    )

    title = models.CharField(max_length=250)  # Titlul postării
    slug = models.SlugField(max_length=250, unique_for_date='publish')  # Slug unic pentru data publicării
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blog_posts')  # Relație cu autorul (User)
    body = models.TextField()  # Conținutul postării
    publish = models.DateTimeField(default=timezone.now)  # Data publicării
    created = models.DateTimeField(auto_now_add=True)  # Data creării
    updated = models.DateTimeField(auto_now=True)  # Data ultimei actualizări
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='draft')  # Starea postării
    active= models.BooleanField(default=True)
    image = models.ImageField(upload_to='post_images/', null=True, blank=True)  # Adăugăm câmpul pentru imagine

    def get_absolute_url(self):
        return reverse(
            'blog:post_detail',args=[self.publish.year,self.publish.month,self.publish.day,self.slug])


# Modelul Comment
class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')  # Comentariile sunt asociate cu postări
    name = models.CharField(max_length=80)  # Numele persoanei care comentează
    email = models.EmailField()  # Email-ul persoanei care comentează
    body = models.TextField()  # Conținutul comentariului
    created = models.DateTimeField(auto_now_add=True)  # Data creării comentariului
    updated = models.DateTimeField(auto_now=True)  # Data ultimei actualizări a comentariului
    active = models.BooleanField(default=True)  # Comentariul este activ

    class Meta:
        ordering = ('created',)  # Comentariile vor fi afișate în ordine cronologică

    def __str__(self):
        return 'Comment by {} on {}'.format(self.name, self.post)

