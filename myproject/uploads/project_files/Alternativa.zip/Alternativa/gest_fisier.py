# Calea fișierului
calea_fisierului = "fisier.txt"

# Funcție de citire a datelor din fișier
def citire_din_fisier():
    try:
        with open(calea_fisierului, 'r') as fisier:
            linii = fisier.readlines()
    except :
        print("Fi;ierul nu exist[")

    mancaruri = []
    for linie in linii:
        fel, ingrediente = linie.strip().split(':')
        lista_ingrediente = ingrediente.split(', ')
        mancaruri.append((fel, lista_ingrediente))
    return mancaruri

#scrierea datelor ]n fișier
def scriere_in_fisier(fel, ingrediente):
    with open(calea_fisierului, 'a') as fisier:
        fisier.write(f"{fel}: {', '.join(ingrediente)}\n")

#căutarea unui ingredient
def cauta_ingredient(ingredient):
    mancaruri = citire_din_fisier()

    feluri_gasite = []
    for fel, ingrediente in mancaruri:
        if ingredient in ingrediente:
            feluri_gasite.append((fel, ingrediente))

    if feluri_gasite:
        print(f"Ingredientul '{ingredient}' a fost găsit în {len(feluri_gasite)} feluri de mâncare:")
        for fel, ingrediente in feluri_gasite:
            print(f" - {fel}: {', '.join(ingrediente)}")
    else:
        print(f"Ingredientul '{ingredient}' nu a fost găsit în niciun fel de mâncare.")
